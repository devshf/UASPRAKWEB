<?php

namespace App\Models;

use CodeIgniter\Model;

class Matakuliah extends Model
{
  protected $table = 'matkul';
  protected $primaryKey = 'id';
  protected $allowedFields = ['id', 'kode_matkul', 'nama', 'sks'];

  public function getMatkul($id = false)
  {
    if ($id == false) {
      return $this->findAll();
    }

    return $this->where(['id' => $id])->first();
  }

  public function updateMatkul($id, $data)
  {
    return $this->update($id, $data);
  }

  public function deleteMatkul($id)
  {
    return $this->where('id', $id)->delete();
  }

  public function saveMatkul($data)
  {
    return $this->insert($data);
  }
}
