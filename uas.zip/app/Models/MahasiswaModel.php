<?php

namespace App\Models;

use CodeIgniter\Model;

class MahasiswaModel extends Model
{
  protected $table = 'mahasiswa';
  protected $primaryKey = 'id';
  protected $allowedFields = ['id', 'nim', 'nama', 'kelas', 'email', 'alamat'];

  public function getMahasiswa($id = false)
  {
    if ($id == false) {
      return $this->findAll();
    }

    return $this->where(['id' => $id])->first();
  }

  public function updateMahasiswa($id, $data)
  {
    return $this->update($id, $data);
  }

  public function deleteMahasiswa($id)
  {
    return $this->where('id', $id)->delete();
  }

  public function saveMahasiswa($data)
  {
    return $this->insert($data);
  }
}
