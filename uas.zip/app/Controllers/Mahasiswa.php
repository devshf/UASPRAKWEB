<?php

namespace App\Controllers;

use App\Models\MahasiswaModel;

class Mahasiswa extends BaseController
{
	protected $MahasiswaModel;
	public function __construct()
	{
		$this->mahasiswaModel = new MahasiswaModel();
	}

	public function index()
	{

		$mahasiswa = $this->mahasiswaModel->getMahasiswa();
		$data = [
			'mahasiswa' => $mahasiswa
		];
		return view('view_mhs', $data);
	}

	public function create()
	{
		$data = [
			'title' => 'Form Tambah Data Mahasiswa'
		];

		return view('view_create', $data);
	}

	public function save($id = null)
	{
		$data = [
			'nim' => $this->request->getVar('nim'),
			'nama' => $this->request->getVar('nama'),
			'kelas' => $this->request->getVar('kelas'),
			'email' => $this->request->getVar('email'),
			'alamat' => $this->request->getVar('alamat'),
		];
		if ($id == null) {
			$this->mahasiswaModel->saveMahasiswa($data);
		} else {
			$this->mahasiswaModel->updateMahasiswa($id, $data);
		}
		return redirect()->to('/mahasiswa');
	}

	public function delete($id)
	{
		$this->mahasiswaModel->deleteMahasiswa($id);
		return redirect()->to('/mahasiswa');
	}

	public function update($id)
	{

		$data = [
			'title' => 'Form Update Data Mahasiswa',
			'mahasiswa' => $this->mahasiswaModel->getMahasiswa($id),
		];

		return view('view_update', $data);
	}
}
