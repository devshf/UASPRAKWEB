<?php
session_start();
require "conf.php";

if( isset($_COOKIE['id']) && isset($_COOKIE['key']))
{
  $id = $_COOKIE['id']; 
  $key = $_COOKIE['key'];

  $result = mysqli_query($koneksi, "SELECT username FROM tb_user WHERE id_user = $id");
  $row = mysqli_fetch_assoc($result);

  if($key == hash('sha256', $row['username']))
  {
    $_SESSION['login'] = true;
  }
}

if (isset($_SESSION["login"]))
{
  header("location: template/tempHome.php");
  exit;
}

if(isset($_POST["login"]))
{
  $username = $_POST["username"];
  $password = $_POST["password"];

  $result = mysqli_query($koneksi, "SELECT * FROM tb_user WHERE username = '$username'");

  if( mysqli_num_rows($result) === 1)
  {
    $row = mysqli_fetch_assoc($result);
    if (password_verify($password, $row["password"]))
    {
      $_SESSION["login"] = true;
      if(isset($_POST["remember"]))
      {
        setcookie('id', $row['id_user'], time()+60);
        setcookie('key', hash('sha256',$row['username']), time()+60);
      }
      header('Location: template/tempHome.php');
      exit;
    }
  }
  $error = true;
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>UAS Praktikum Web</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous" />

    <!-- CSS -->
    <link href="style/style.css" rel="stylesheet" />
  </head>
    <body id="body">

    <!-- navbar -->
    <nav class="navbar navbar-expand-lg navbar-light sticky-top" style="background-color: white">
      <div class="container">
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav ms-auto">
            <li class="nav-item">
              <a class="nav-link active" href="tempHome.php">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="tempMahasiswa.php">Mahasiswa</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="tempMatkul.php">Mata Kuliah</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="tempDosen.php">Dosen</a>
            </li>
          
            <ul class="navbar-nav">
                <a class="navbar-nav mb-2 ml-2" href="user.html"><img src="/asset/person.svg" alt="Person" height="30">
                </a>
            </ul>

          </ul>
          
          

        </div>
      </div>
    </nav>
    <!-- end of navbar -->

    <!-- javascript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

  </body>
</html>
